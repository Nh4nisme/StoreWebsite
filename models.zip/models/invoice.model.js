const mongoose = require('mongoose');

const invoiceItemSchema = new mongoose.Schema({
    product: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Products',
        required: true
    },
    productName: { type: String, required: true },
    unitPrice: { type: Number, required: true },
    quantity: { type: Number, required: true },
    totalPrice: { type: Number, required: true }
}, { _id: false });

const invoiceSchema = new mongoose.Schema({
    invoiceNumber: { type: String, required: true, unique: true },
    createdAt: { type: Date, default: Date.now, required: true },
    employeeId: { type: String, required: true },
    employeeName: { type: String, required: true },
    customerName: { type: String, required: true },
    customerPhone: { type: String },
    items: [invoiceItemSchema],
    subtotal: { type: Number, required: true },
    taxRate: { type: Number, default: 0 },
    taxAmount: { type: Number, default: 0 },
    discountPercent: { type: Number, default: 0 },
    discountAmount: { type: Number, default: 0 },
    totalAmount: { type: Number, required: true },
    paymentMethod: { type: String, required: true },
    customerPaid: { type: Number, required: true },
    change: { type: Number, required: true },
    notes: { type: String }
});

module.exports = mongoose.model('Invoice', invoiceSchema, 'HoaDonKhachHang');